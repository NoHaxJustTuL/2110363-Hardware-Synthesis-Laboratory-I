module cocotb_iverilog_dump();
initial begin
    string dumpfile_path;    if ($value$plusargs("dumpfile_path=%s", dumpfile_path)) begin
        $dumpfile(dumpfile_path);
    end else begin
        $dumpfile("C:\\Users\\thana\\OneDrive\\Desktop\\HW-SYS-Lab\\lab1\\part3\\part3-2\\sim_build\\sim_build\\jkff.fst");
    end
    $dumpvars(0, jkff);
end
endmodule
